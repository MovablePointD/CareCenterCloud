package com.edu.controller;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.edu.entity.Role;
import com.edu.entity.User;
import com.edu.service.RoleService;
import com.edu.service.UserRoleService;
import com.edu.service.UserService;
import com.edu.vo.ResultVo;
import com.edu.vo.RoleUserVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author zhaojie
 * @since 2024-08-21
 */
@RestController
@RequestMapping("/userRole")
public class UserRoleController {
    @Resource
    UserService userService;
    @Resource
    RoleService roleService;
    @Resource
    UserRoleService userRoleService;
    @GetMapping("/getUser")
    ResultVo<RoleUserVo> getUserList(Long roleId){

        return ResultVo.success(new RoleUserVo(userService.getList(),userRoleService.getByRoleId(roleId)));
    }
    @PostMapping("/save")
    ResultVo<Boolean> save(Long roleId, Long[] userIds){
        Role role= roleService.getById(roleId);
        for (Long userId : userIds) {
            UpdateWrapper<User>wrapper=new UpdateWrapper<>();
            wrapper.eq("id",userId);
            wrapper.set("type",role.getName());
            userService.update(wrapper);

        }
        return ResultVo.success(userRoleService.save(roleId, userIds));
    }

}
