package com.edu.controller.aichat;

import com.edu.service.aichat.ElderlyCareRagService;
import com.edu.service.aichat.QwenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/ai")
public class AiController {

    @Autowired
    private QwenService qwenService;

    @Autowired
    private ElderlyCareRagService elderlyCareRagService;

//    @PostMapping("/chat")
//    public String askQwen(@RequestBody Map<String, String> request) {
//        String question = request.get("question");
//        return qwenService.callQwen(question);
//    }

//    @PostMapping("/ask")
//    public String askQwen(@RequestBody Map<String, String> request) {
//        String question = request.get("question");
//
//        // ✅ 固定系统提示词
//        String systemPrompt = "你是一个专业、幽默、乐于助人的AI助手，回答请控制在100字以内。";
//
//        return qwenService.callQwenWithSystemPrompt(systemPrompt, question);
//    }

    @PostMapping("/rag")
    public String ask(@RequestBody Map<String, String> request) {
        String question = request.get("question");
        return elderlyCareRagService.ask(question);
    }

}
