package com.edu.core;

public class EduException extends RuntimeException {

    public EduException(String message) {
        super(message);
    }
}
