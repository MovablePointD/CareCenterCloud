package com.edu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.entity.Dietarymanagement;

/**
 * <p>
 * 膳食管理 Mapper 接口
 * </p>
 *
 * @author zza
 * @since 2024-08-15
 */
public interface DietarymanagementMapper extends BaseMapper<Dietarymanagement> {

}
