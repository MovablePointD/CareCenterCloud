package com.edu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.entity.Dietarycalendar;

public interface DietarycalendaMapper extends BaseMapper<Dietarycalendar>{

}
