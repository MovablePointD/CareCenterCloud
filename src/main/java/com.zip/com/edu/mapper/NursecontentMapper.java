package com.edu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.entity.Nursecontent;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author mengxiang
 * @since 2024-08-13
 */
public interface NursecontentMapper extends BaseMapper<Nursecontent> {

//    Boolean updatememo(String memo,Integer id);
}
