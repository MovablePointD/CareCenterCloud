package com.edu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.entity.Servicetargets;

/**
 * <p>
 * 服务对象 Mapper 接口
 * </p>
 *
 * @author zhaojie
 * @since 2024-08-30
 */
public interface ServicetargetsMapper extends BaseMapper<Servicetargets> {

}
