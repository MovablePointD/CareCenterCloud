package com.edu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.entity.Nursingrecords;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author mengxiang
 * @since 2024-08-09
 */
public interface NursingrecordsMapper extends BaseMapper<Nursingrecords> {

}
