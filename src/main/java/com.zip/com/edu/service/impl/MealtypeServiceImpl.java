package com.edu.service.impl;

import com.edu.entity.Mealtype;
import com.edu.mapper.MealtypeMapper;
import com.edu.service.MealtypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 菜品类型表 服务实现类
 * </p>
 *
 * @author zhaojie
 * @since 2024-08-26
 */
@Service
public class MealtypeServiceImpl extends ServiceImpl<MealtypeMapper, Mealtype> implements MealtypeService {

}
