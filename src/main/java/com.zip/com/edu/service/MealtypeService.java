package com.edu.service;

import com.edu.entity.Mealtype;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 菜品类型表 服务类
 * </p>
 *
 * @author zhaojie
 * @since 2024-08-26
 */
public interface MealtypeService extends IService<Mealtype> {

}
